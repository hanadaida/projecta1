const {User} = require('../models/user'); // Importation du modèle User
const express = require('express');
const router = express.Router(); // Création d'un objet routeur
const bcrypt = require('bcryptjs');// Importation de bcrypt pour le hachage des mots de passe
const jwt = require('jsonwebtoken');// Importation de jwt pour l'authentification

// Obtention de la liste des utilisateurs sans le mot de passe
router.get(`/`, async (req, res) =>{
    const userList = await User.find().select('-passwordHash');

    if(!userList) {
        res.status(500).json({success: false}) // Envoi d'une réponse d'erreur si la liste des utilisateurs est falsy
    } 
    res.send(userList); // Envoi de la liste des utilisateurs
})

// Obtention d'un seul utilisateur sans le mot de passe
router.get('/:id', async(req,res)=>{
    const user = await User.findById(req.params.id).select('-passwordHash');

    if(!user) {
        res.status(500).json({message: 'L\'utilisateur avec l\'ID fourni n\'a pas été trouvé.'}) // Envoi d'une réponse d'erreur si l'utilisateur n'est pas trouvé
    } 
    res.status(200).send(user); // Envoi des données de l'utilisateur
})

// Enregistrement d'un nouvel utilisateur
router.post('/', async (req,res)=>{
    let user = new User({ // Création d'un nouvel objet User
        name: req.body.name,
        email: req.body.email,
        passwordHash: bcrypt.hashSync(req.body.password, 10), // Hachage du mot de passe
        phone: req.body.phone,
        isAdmin: req.body.isAdmin,
        street: req.body.street,
        apartment: req.body.apartment,
        zip: req.body.zip,
        city: req.body.city,
        country: req.body.country,
    })
    user = await user.save(); // Sauvegarde de l'utilisateur dans la base de données

    if(!user)
    return res.status(400).send('Impossible de créer l\'utilisateur !') // Envoi d'une réponse d'erreur si la création de l'utilisateur échoue

    res.send(user); // Envoi des données de l'utilisateur créé
})

// Mise à jour des détails de l'utilisateur
router.put('/:id',async (req, res)=> {

    const userExist = await User.findById(req.params.id);
    let newPassword
    if(req.body.password) {
        newPassword = bcrypt.hashSync(req.body.password, 10) // Hachage du nouveau mot de passe s'il est fourni
    } else {
        newPassword = userExist.passwordHash; // Utilisation du hachage du mot de passe existant si le nouveau mot de passe n'est pas fourni
    }

    const user = await User.findByIdAndUpdate(
        req.params.id,
        {
            name: req.body.name,
            email: req.body.email,
            passwordHash: newPassword,
            phone: req.body.phone,
            isAdmin: req.body.isAdmin,
            street: req.body.street,
            apartment: req.body.apartment,
            zip: req.body.zip,
            city: req.body.city,
            country: req.body.country,
        },
        { new: true}
    )

    if(!user)
    return res.status(400).send('Impossible de mettre à jour l\'utilisateur !') // Envoi d'une réponse d'erreur si la mise à jour de l'utilisateur échoue

    res.send(user); // Envoi des données de l'utilisateur mis à jour
})

// Connexion via l'e-mail et le mot de passe
router.post('/login', async (req,res) => {
    const user = await User.findOne({email: req.body.email}) // Recherche de l'utilisateur par e-mail

    if(!user) {
        return res.status(400).send('L\'utilisateur n\'a pas été trouvé'); // Envoi d'une réponse d'erreur si l'utilisateur n'est pas trouvé
    }

    if(user && bcrypt.compareSync(req.body.password, user.passwordHash)) // Comparaison du hachage du mot de passe
    { 
        // Génération du jeton JWT pour l'authentification
        const token = jwt.sign(
            {
                userId: user.id,
                isAdmin: user.isAdmin
            },
            process.env.secret,
            {expiresIn : '1d'} // Temps d'expiration du jeton
        )
       
        res.status(200).send({user: user.email , token: token}) // Envoi de l'e-mail de l'utilisateur et du jeton
    } else {
       res.status(400).send('Le mot de passe est incorrect !'); // Envoi d'une réponse d'erreur si le mot de passe est incorrect
    }
})

// Enregistrement d'un nouvel utilisateur
router.post('/register', async (req,res)=>{
    let user = new User({ // Création d'un nouvel objet User
        name: req.body.name,
        email: req.body.email,
        passwordHash: bcrypt.hashSync(req.body.password, 10), // Hachage du mot de passe
        phone: req.body.phone,
        isAdmin: req.body.isAdmin,
        street: req.body.street,
        apartment: req.body.apartment,
        zip: req.body.zip,
        city: req.body.city,
        country: req.body.country,
    })
    user = await user.save(); // Sauvegarde de l'utilisateur dans la base de données

    if(!user)
    return res.status(400).send('Impossible de créer l\'utilisateur !') // Envoi d'une réponse d'erreur si la création de l'utilisateur échoue

    res.send(user); // Envoi des données de l'utilisateur créé
})

// Suppression d'un utilisateur par ID
router.delete('/:id', (req, res)=>{
    User.findByIdAndRemove(req.params.id).then(user =>{
        if(user) {
            return res.status(200).json({success: true, message: 'L\'utilisateur a été supprimé !'}) // Envoi d'une réponse de succès si l'utilisateur est supprimé
        } else {
            return res.status(404).json({success: false , message: "Utilisateur non trouvé !"}) // Envoi d'une réponse d'erreur si l'utilisateur n'est pas trouvé
        }
    }).catch(err=>{
       return res.status(500).json({success: false, error: err}) // Envoi d'une réponse d'erreur pour toute autre erreur
    })
})

// Obtention du nombre d'utilisateurs
router.get(`/get/count`, async (req, res) =>{
    const userCount = await User.countDocuments((count) => count)

    if(!userCount) {
        res.status(500).json({success: false}) // Envoi d'une réponse d'erreur si le nombre d'utilisateurs n'est pas trouvé
    } 
    res.send({
        userCount: userCount
    });
})

module.exports =router; // Exportation