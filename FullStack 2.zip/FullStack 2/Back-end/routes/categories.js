const {Category}=require('../models/category');
const express=require('express');
const router = express.Router();



router.get('/', async (req, res) => {

    const categorytList = await Category.find();

if(!categorytList){
    res.status(500).json({success: false})
}


    res.send(categorytList);
});

router.get("/:id",async(req,res)=> {

    const category = await Category.findById(req.params.id);
    if(!category){
        return res.status(200).json({success:true, message:"the category with this id does not exist"})
    }
    res.send(category);

})


router.put("/:id", async(req,res)=> {
    const category = await Category.findByIdAndUpdate(req.params.id,
        {
            name:req.body.name,
            icon:req.body.icon,
            color:req.body.color
        },
        {new:true}
        )
        if(!category)
        return res.status(400).send("category cannot be created");

        res.send(category);
})

router.post('/', async (req,res)=>{
    let category = new Category(
        {
            name:req.body.name,
            icon:req.body.icon,
            color:req.body.color
        }
    )
    category = await category.save();
    if (!category)
    res.status(400).send("category already created");

    res.send(category)
})

router.delete("/:id",(req,res)=>{
    Category.findByIdAndDelete(req.params.id).then(category => 
    {
    if(category){
        return res.status(200).json({success: true,message: "category has been deleted"})
    }else{
        return res.status(404).send({success:false, message:"category not found!"})
    }}).catch(err => {
        return res.status(400).json({success:false,error:err})
    })
})

module.exports=router;